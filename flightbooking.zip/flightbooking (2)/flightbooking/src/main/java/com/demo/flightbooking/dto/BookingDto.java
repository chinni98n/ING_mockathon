package com.demo.flightbooking.dto;

import java.util.List;

import com.demo.flightbooking.entity.FlightDetail;

public class BookingDto {
	private String email;
	private String flightId;
	List<FlightDetail> flightDetail;
	
	
	public List<FlightDetail> getFlightDetail() {
		return flightDetail;
	}
	public void setFlightDetail(List<FlightDetail> flightDetail) {
		this.flightDetail = flightDetail;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFlightId() {
		return flightId;
	}
	public void setFlightId(String flightId) {
		this.flightId = flightId;
	}
	

}
