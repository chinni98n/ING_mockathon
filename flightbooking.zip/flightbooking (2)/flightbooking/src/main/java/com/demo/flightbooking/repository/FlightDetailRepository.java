package com.demo.flightbooking.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.flightbooking.entity.FlightDetail;

public interface FlightDetailRepository extends JpaRepository<FlightDetail, Integer> {

}
