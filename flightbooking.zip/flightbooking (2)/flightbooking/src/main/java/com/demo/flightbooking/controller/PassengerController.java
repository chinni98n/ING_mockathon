package com.demo.flightbooking.controller;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.demo.flightbooking.dto.LoginDto;
import com.demo.flightbooking.dto.PassengerDto;
import com.demo.flightbooking.entity.Passenger;
import com.demo.flightbooking.exception.PassengerException;
import com.demo.flightbooking.service.PassengerService;
import com.demo.flightbooking.utility.ErrorConstant;

@RestController
public class PassengerController {

	@Autowired
	PassengerService passengerService;
/**
 * 
 * @param passenger
 * @return registration for passenger
 * @throws PassengerException
 */
	@PostMapping("/createPassenger")
	public ResponseEntity<String> createPassenger(@RequestBody PassengerDto passengerDto) throws PassengerException {
	  Passenger passenger=new Passenger();
	  passenger.setLoggedIn(false);
		BeanUtils.copyProperties(passengerDto, passenger);
		String message=passengerService.createPassenger(passenger);
		return new ResponseEntity<String>(message, HttpStatus.OK);

	}
/**
 * 
 * @param email
 * @return passenger record using passenger email id
 * @throws PassengerException
 */
	@GetMapping("/passenger/{email}")
	public ResponseEntity<Passenger> getPassengerByEmail(@PathVariable("email") String email)
			throws PassengerException {

		return new ResponseEntity<Passenger>(passengerService.getByEmail(email), HttpStatus.FOUND);
	}
/**
 * 
 * @return get all registered passengers detail
 * @throws PassengerException
 */
	@GetMapping("/getPassengerDetails")
	public ResponseEntity<List<Passenger>> getAllPassengers() throws PassengerException {

		return new ResponseEntity<List<Passenger>>(passengerService.getAllPassengers(), HttpStatus.FOUND);
	}
/**
 * 
 * @param passenger
 * @return update passenger detail
 * @throws PassengerException
 */
	@PutMapping("/updatePassengerDetails")
	public ResponseEntity<String> updatePassengerDetails(@RequestBody PassengerDto passengerDto) throws PassengerException {
		 Passenger passenger=new Passenger();
			BeanUtils.copyProperties(passengerDto, passenger);
		passengerService.updatePassenger(passenger);
		return new ResponseEntity<String>("updated successfully", HttpStatus.ACCEPTED);
	}

	/**
	 * 
	 * @param email
	 * @return delete particular passenger record using email id
	 * @throws PassengerException
	 */
	@DeleteMapping("/deletePassenger/{email}")
	public ResponseEntity<String> deletePassenger(@PathVariable("email") String email) throws PassengerException {
		passengerService.delete(email);
		return new ResponseEntity<String>(ErrorConstant.PASSENGER_DELETE, HttpStatus.OK);
	}
/**
 * 
 * @param loginDto
 * @return login passenger to book ticket
 * @throws PassengerException
 */
	@PostMapping("/login")
	public ResponseEntity<String> loginPassenger(@RequestBody LoginDto loginDto) throws PassengerException {
		return new ResponseEntity<String>(passengerService.login(loginDto), HttpStatus.OK);
	}
/**
 * 
 * @param email
 * @return logout passenger
 * @throws PassengerException
 */
	@PostMapping("/logout/{email}")
	public ResponseEntity<String> logoutPassenger(@PathVariable("email") String email) throws PassengerException {
		passengerService.logoutPassenger(email);
		return new ResponseEntity<String>("logged out successfully", HttpStatus.ACCEPTED);

	}

}
