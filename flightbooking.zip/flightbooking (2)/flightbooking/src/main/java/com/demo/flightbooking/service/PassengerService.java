package com.demo.flightbooking.service;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.flightbooking.dto.LoginDto;
import com.demo.flightbooking.entity.Passenger;
import com.demo.flightbooking.exception.PassengerException;
import com.demo.flightbooking.repository.PassengerRepository;
import com.demo.flightbooking.utility.ErrorConstant;

@Service
public class PassengerService {

	@Autowired
	PassengerRepository passengerRepository;
	@Autowired
	EntityManager entityManager;

	/**
	 * 
	 * @param passenger
	 * @return If Passenger registered successfully it return passenger saved
	 *         successfully or else it return email id already exists
	 */
	public String createPassenger(Passenger passenger) {
		try {
			passengerRepository.save(passenger);
			return "passenger saved successfully";
		} catch (Exception e) {
			return "email id already exists " + passenger.getEmail();
		}
	}

	/**
	 * 
	 * @return List of all passengers
	 * @throws PassengerException
	 */
	public List<Passenger> getAllPassengers() throws PassengerException {
		List<Passenger> passengerList = passengerRepository.findAll();
		if (passengerList.isEmpty()) {
			throw new PassengerException(ErrorConstant.PASSENGER_RECORD_NOT_FOUND);
		} else {
			return passengerList;
		}
	}

	/**
	 * Update Passenger detail
	 * 
	 * @param passenger
	 * @throws PassengerException
	 */
	public void updatePassenger(Passenger passenger) throws PassengerException {

		Session session = entityManager.unwrap(Session.class);
		Optional<Passenger> updatePassenger = passengerRepository.findByEmail(passenger.getEmail());
		if (!updatePassenger.isPresent()) {
			throw new PassengerException(ErrorConstant.PASSENGER_RECORD_NOT_FOUND);
		}
		Transaction transaction = session.beginTransaction();
		updatePassenger.get().setPassword(passenger.getPassword());
		updatePassenger.get().setLoggedIn(passenger.isLoggedIn());

		session.update(updatePassenger.get());
		transaction.commit();
		session.close();

	}

	/**
	 * delete passenger record
	 * 
	 * @param email
	 * @throws PassengerException
	 */
	public void delete(String email) throws PassengerException {
		Optional<Passenger> passenger = passengerRepository.findByEmail(email);
		if (!passenger.isPresent()) {
			throw new PassengerException(ErrorConstant.PASSENGER_NOT_FOUND);
		} else
			passengerRepository.deleteById(passenger.get().getId());

	}

	/**
	 * 
	 * @param loginDto
	 * @return check whether passenger logged in successfully or not
	 * @throws PassengerException
	 */
	public String login(LoginDto loginDto) throws PassengerException {
		List<Passenger> passengerList = passengerRepository.findByEmailAndPassword(loginDto.getEmail(),
				loginDto.getPassword());

		if (passengerList.isEmpty()) {
			throw new PassengerException(ErrorConstant.PASSENGER_LOGIN_ERROR);

		} else {
			Optional<Passenger> passenger = passengerRepository.findByEmail(loginDto.getEmail());
			if (!passenger.isPresent()) {

				throw new PassengerException(ErrorConstant.PASSENGER_RECORD_NOT_FOUND);

			}
			passenger.get().setLoggedIn(true);
			Session session = entityManager.unwrap(Session.class);

			Transaction transaction = session.beginTransaction();
			session.save(passenger.get());
			transaction.commit();
			return ErrorConstant.PASSENGER_LOGIN_SUCCESS;
		}
	}

	/**
	 * 
	 * @param email
	 * @return Passenger detail by email
	 * @throws PassengerException
	 */
	public Passenger getByEmail(String email) throws PassengerException {
		Optional<Passenger> passenger = passengerRepository.findByEmail(email);
		if (!passenger.isPresent()) {
			throw new PassengerException(ErrorConstant.PASSENGER_NOT_FOUND);
		} else {
			return passenger.get();
		}

	}

	/**
	 * passenger logout
	 * 
	 * @param email
	 * @throws PassengerException
	 */
	public void logoutPassenger(String email) throws PassengerException {
		Optional<Passenger> passenger = passengerRepository.findByEmail(email);

		if (!passenger.isPresent()) {
			throw new PassengerException(ErrorConstant.PASSENGER_NOT_FOUND);
		} else {
			if (!passenger.get().isLoggedIn()) {
				throw new PassengerException(ErrorConstant.PASSENGER_ALREADY_LOGGED_OUT);
			} else {
				passenger.get().setLoggedIn(false);
				Session session = entityManager.unwrap(Session.class);
				Transaction transaction = session.beginTransaction();
				session.update(passenger.get());
				transaction.commit();

			}
		}
	}

}
