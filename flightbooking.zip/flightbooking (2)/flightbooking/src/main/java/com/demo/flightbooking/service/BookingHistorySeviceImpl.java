package com.demo.flightbooking.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.flightbooking.dto.BookingHistory;
import com.demo.flightbooking.entity.Passenger;
import com.demo.flightbooking.entity.PassengerFlight;
import com.demo.flightbooking.repository.PassengerFlightRepo;
import com.demo.flightbooking.repository.PassengerRepo;

@Service
public class BookingHistorySeviceImpl implements BookingHistoryService {

	@Autowired
	PassengerFlightRepo passengerFlightRepo;

	@Autowired
	PassengerRepo passengerRepo;
/**
 * @param String email
 * @return Display list of booking history of passenger using passenger email id 
 */
	@Override
	public List<BookingHistory> getBookingHistory(String email) {

		Passenger passenger = passengerRepo.findByEmail(email);
		List<BookingHistory> list = new ArrayList<BookingHistory>();
		List<PassengerFlight> list1 = passenger.getPassengerFligt();
		
		int i = 0;
		for (PassengerFlight pf : list1) {
			BookingHistory bh = new BookingHistory();
			bh.setBookingDate(passenger.getPassengerFligt().get(i).getDateTime());
			bh.setFlight_id(passenger.getPassengerFligt().get(i).getFlight().getFlightId());
			bh.setNoOfPassengers(passenger.getPassengerFligt().get(i).getTicketBooked());
			bh.setSource(passenger.getPassengerFligt().get(i).getFlight().getSource());
			bh.setDestination(passenger.getPassengerFligt().get(i).getFlight().getDestination());
			bh.setPassenger_id(passenger.getId());
			list.add(bh);
			i++;
		}

		return list;

	}

}
