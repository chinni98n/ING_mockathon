package com.demo.flightbooking.exception;

public class FlightException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FlightException(String arg0) {
		super(arg0);
		
	}
	

}
