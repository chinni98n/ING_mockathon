package com.demo.flightbooking.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.flightbooking.dto.FlightDto;
import com.demo.flightbooking.entity.Flight;
import com.demo.flightbooking.exception.FlightException;
import com.demo.flightbooking.service.FlightService;

@RestController
public class FlightController {



	@Autowired
	FlightService flightservice;
/**
 * 
 * @return  all the flight details
 */
	@GetMapping("/getFlightDetails")
	public List<Flight> getAllFlights() {
		return flightservice.getAllFlight();
	}
/**
 * 
 * @param flightDto
 * @return  register for new flight
 * @throws FlightException
 * @throws ParseException
 */
	@PostMapping("/createFlight")
	public ResponseEntity<String> createFlight(@RequestBody FlightDto flightDto)
			throws FlightException, ParseException {

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		
		Date requiredDate = format.parse(flightDto.getDate());
		
		Flight flight = new Flight();
		flight.setDate(requiredDate);
		BeanUtils.copyProperties(flightDto, flight);

		flightservice.createFlight(flight);
		
		return new ResponseEntity<String>("registered", HttpStatus.CREATED);
	}

/**
 * 
 * @param flight
 * @return update flight detail
 * @throws FlightException
 */
	@PutMapping("/updateFlightDetails")
	public Flight updateFlightDetails(@RequestBody FlightDto flightDto) throws FlightException {
		Flight flight=new Flight();
		BeanUtils.copyProperties(flightDto, flight);
		flightservice.updateFlight(flight);
		return flight;
	}

	/**
	 * 
	 * @param flightid
	 * @return delete particular flight using flightId
	 * @throws FlightException
	 */
	@DeleteMapping("/deleteFlight/{flightId}")
	public ResponseEntity<String> deleteFlight(@RequestParam("flightId") String flightid) throws FlightException {
		flightservice.deleteByFlightId(flightid);
		return new ResponseEntity<String>("deleted", HttpStatus.ACCEPTED);
	}
/**
 * 
 * @param id
 * @return search particular flight based on Flight id
 * @throws FlightException
 */
	@GetMapping("/flight/{flight_id}")
	public ResponseEntity<Flight> findbyflightid(@RequestParam String id) throws FlightException {

		Flight flight = flightservice.getFlightById(id);

		return new ResponseEntity<Flight>(flight, HttpStatus.OK);
	}

}
