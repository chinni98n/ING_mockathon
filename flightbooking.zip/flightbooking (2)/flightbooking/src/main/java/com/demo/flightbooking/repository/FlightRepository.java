package com.demo.flightbooking.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.demo.flightbooking.entity.Flight;

public interface FlightRepository extends JpaRepository<Flight, Integer> {
	Optional<Flight> findByFlightId(String id);

	public List<Flight> findBySourceAndDestinationAndDate(String source, String destination, Date date);

	@Query(value = "select * from flight where source=?1 and destination=?2 and date=?3", nativeQuery = true)
	public List<Flight> getListOfFlights(String source, String destination, Date date);

	}
