package com.demo.flightbooking.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.flightbooking.dto.BookingDto;
import com.demo.flightbooking.entity.Flight;
import com.demo.flightbooking.entity.FlightDetail;
import com.demo.flightbooking.entity.Passenger;
import com.demo.flightbooking.entity.PassengerFlight;
import com.demo.flightbooking.exception.FlightException;
import com.demo.flightbooking.exception.PassengerException;
import com.demo.flightbooking.repository.FlightDetailRepository;
import com.demo.flightbooking.repository.FlightRepository;
import com.demo.flightbooking.repository.PassengerFlightRepository;
import com.demo.flightbooking.repository.PassengerRepository;
import com.demo.flightbooking.utility.ErrorConstant;

@Service
public class FlightBookingService {
	@Autowired
	FlightRepository flightRepository;
	@Autowired
	PassengerRepository passengerRepository;
	@Autowired
	FlightDetailRepository flightDetailRepository;
	@Autowired
	PassengerFlightRepository passengerFlight;
	@Autowired
	EntityManager entityManager;

	/**
	 * @author prateek.pal
	 * @param bookingDto
	 * @throws Exception
	 * @return check whether the flight booked successfully or not
	 * @throws PassengerException 
	 * @throws FlightException 
	 */
	public void bookFlight(BookingDto bookingDto) throws PassengerException, FlightException {
		List<FlightDetail> flightDetail = bookingDto.getFlightDetail();

		Optional<Flight> flight = flightRepository.findByFlightId(bookingDto.getFlightId());

		Optional<Passenger> passenger = passengerRepository.findByEmail(bookingDto.getEmail());
		if (!passenger.isPresent()) {

			throw new PassengerException(ErrorConstant.EMAIL_NOT_FOUND);
		} else if (!passenger.get().isLoggedIn()) {
			throw new PassengerException(ErrorConstant.PASSENGER1_LOGIN_ERROR);
		}

		else if (!flight.isPresent()) {
			throw new FlightException(ErrorConstant.FLIGHT_NOT_FOUND);
		} else if (flight.get().getSeatAvailable() < flightDetail.size()) {
			throw new FlightException(ErrorConstant.NOT_ENOUGH_SEAT);

		} else {

			PassengerFlight passengerFlights = new PassengerFlight();
			passengerFlights.setDateTime(new Date());
			passengerFlights.setFlight(flight.get());
			passengerFlights.setPassenger(passenger.get());
			passengerFlights.setTicketBooked(flightDetail.size());
			passengerFlights.setFlightDetail(flightDetail);
			passengerFlight.save(passengerFlights);
			Flight flights = flight.get();
			int seat = flights.getSeatAvailable();
			flights.setSeatAvailable(seat - flightDetail.size());
			Session session = entityManager.unwrap(Session.class);
			Transaction transaction = session.beginTransaction();
			session.save(flights);
			transaction.commit();

		}
	}

	/**
	 * 
	 * @param source
	 * @param destination
	 * @param date
	 * @throws FlightException
	 * @return List of flight detail available based on particular source
	 *         destination and date
	 */
	public List<Flight> flightBookingService(String source, String destination, Date date) throws FlightException {
		List<Flight> flightList = flightRepository.findBySourceAndDestinationAndDate(source, destination, date);
		if (date.before(new Date())) {
			throw new FlightException(ErrorConstant.INVALID_DATE);
		} else if (flightList.isEmpty()) {
			throw new FlightException(ErrorConstant.FLIGHT_NOT_FOUND);
		} else {

			return flightList;

		}

	}
}
