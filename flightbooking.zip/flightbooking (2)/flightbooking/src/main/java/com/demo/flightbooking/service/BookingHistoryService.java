package com.demo.flightbooking.service;

import java.util.List;

import com.demo.flightbooking.dto.BookingHistory;

public interface BookingHistoryService {

	public List<BookingHistory> getBookingHistory(String email);

}
