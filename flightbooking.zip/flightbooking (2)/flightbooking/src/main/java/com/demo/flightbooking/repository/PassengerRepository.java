package com.demo.flightbooking.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.demo.flightbooking.entity.Passenger;

@Repository
public interface PassengerRepository extends JpaRepository<Passenger,Integer>{
	Optional<Passenger> findByEmail(String email);
	void deleteByEmail(String email);

	List<Passenger> findByEmailAndPassword(String email, String password);
	

	

}
