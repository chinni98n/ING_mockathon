package com.demo.flightbooking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.flightbooking.dto.BookingHistory;
import com.demo.flightbooking.service.BookingHistorySeviceImpl;


@RestController
@RequestMapping("/FlightBooking/passenger")
public class BookingHistoryController {
	
	@Autowired
	BookingHistorySeviceImpl bookingService;
    /**
     * 
     * @param email
     * @return records of Passenger ticket book history
     */
	@GetMapping(value = "/history/email/{email}")
	public List<BookingHistory> getBookingHistory(@PathVariable("email") String email) {
		
		return bookingService.getBookingHistory(email);
	}
}
