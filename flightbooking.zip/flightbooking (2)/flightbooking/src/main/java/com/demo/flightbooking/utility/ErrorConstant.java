package com.demo.flightbooking.utility;

public class ErrorConstant {
public static final String ALREADY_EXIST="Already flight is existed";
public static final String PASSENGER1_LOGIN_ERROR="please log in first!!!";
public static final String NOT_ENOUGH_SEAT="not enough seat available";
public static final String EMAIL_NOT_FOUND="email has not been registerd";
public static final String INVALID_DATE="invalid date";
public static final String PASSENGER_LOGIN_ERROR = "invalid username or password";
public static final String PASSENGER_LOGIN_SUCCESS = "logged in successfully";
public static final String PASSENGER_DELETE = "deleted successfully";
public static final String PASSENGER_DELETE_ERROR = "It requires proper mail";
public static final String PASSENGER_RECORD_NOT_FOUND = "no record found";
public static final String PASSENGER_NOT_FOUND = "passenger not found";
public static final String PASSENGER_ALREADY_LOGGED_OUT = "passenger already logged out";

public static final String FLIGHT_NOT_FOUND="flight not found";
public static final String NO_RECORD_FOUND="no record found";
public static final String ALREADY_EXISTED="Already flight is existed";
private ErrorConstant()
{
	
}


}

