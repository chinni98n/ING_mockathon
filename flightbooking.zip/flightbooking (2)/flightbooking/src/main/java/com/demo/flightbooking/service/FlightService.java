package com.demo.flightbooking.service;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.flightbooking.entity.Flight;
import com.demo.flightbooking.exception.FlightException;
import com.demo.flightbooking.repository.FlightRepository;
import com.demo.flightbooking.utility.ErrorConstant;

@Service
public class FlightService {

	@Autowired
	FlightRepository flightrepository;
	@Autowired
	EntityManager entityManager;

	public List<Flight> getAllFlight() {

		return flightrepository.findAll();
	}
/**
 * Register for new Flight
 * @param flight
 * @throws FlightException
 */
	public void createFlight(Flight flight) throws FlightException{
		Optional<Flight> list = flightrepository.findByFlightId(flight.getFlightId());
		if(!list.isPresent())
	       {
			flightrepository.save(flight);
			
	       }
		else
		{
			
			throw new FlightException(ErrorConstant.ALREADY_EXISTED);
		}
		
	}
/**
 * update flight Record
 * @param flight
 * @throws FlightException
 */
	public void updateFlight(Flight flight) throws FlightException {
		Optional<Flight> flightObject=flightrepository.findByFlightId(flight.getFlightId());
		if(!flightObject.isPresent())
		{
			throw new FlightException(ErrorConstant.FLIGHT_NOT_FOUND);
		}
		flightObject.get().setSeatAvailable(flight.getSeatAvailable());
		Session session=entityManager.unwrap(Session.class);
		Transaction transaction=session.beginTransaction();
		session.update(flightObject.get());
		transaction.commit();
		}

	/**
	 * delete flight details using flight id
	 * @param flightid
	 * @throws FlightException
	 */
	public void deleteByFlightId(String flightid) throws FlightException {
		Optional<Flight> list=flightrepository.findByFlightId(flightid);
		if(!list.isPresent())
	       {
	    	 throw new FlightException(ErrorConstant.NO_RECORD_FOUND);
	       }
		else
		{
			
		 flightrepository.deleteById(list.get().getId());
		}

	}
/**
 * fetch flight detail using flight id
 * @param id
 * @return
 * @throws FlightException
 */
	public Flight getFlightById(String id) throws FlightException {
		Optional<Flight> flight = flightrepository.findByFlightId(id);

		if (!flight.isPresent()) {
			throw new FlightException(ErrorConstant.FLIGHT_NOT_FOUND);
		} else {
			return flight.get();
		}
	}

}
