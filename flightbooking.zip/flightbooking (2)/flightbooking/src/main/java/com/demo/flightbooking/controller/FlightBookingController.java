package com.demo.flightbooking.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.demo.flightbooking.dto.BookingDto;
import com.demo.flightbooking.entity.Flight;
import com.demo.flightbooking.exception.FlightException;
import com.demo.flightbooking.exception.PassengerException;
import com.demo.flightbooking.service.FlightBookingService;

@RestController
public class FlightBookingController {
	@Autowired
	FlightBookingService flightBookingService;

	/**
	 * 
	 * @param bookingDto
	 * @return Ticket Booked
	 * @throws FlightException 
	 * @throws PassengerException 
	 * @throws Exception
	 */
	@PostMapping("/bookFlight")
	public ResponseEntity<String> bookFlight(@RequestBody BookingDto bookingDto) throws PassengerException, FlightException {

		flightBookingService.bookFlight(bookingDto);

		return new ResponseEntity<String>("booked successfully", HttpStatus.ACCEPTED);
	}

	/**
	 * 
	 * @param source
	 * @param destination
	 * @param date
	 * @return List available flight based on source destination and date
	 * @throws ParseException
	 * @throws FlightException
	 */
	@GetMapping("/searchFlight/source/{source}/destination/{destination}/date/{date}")
	public ResponseEntity<List<Flight>> getAvailableFlights(@PathVariable("source") String source,
			@PathVariable("destination") String destination, @PathVariable("date") String date)
			throws ParseException, FlightException {

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date requiredDate = format.parse(date);
		List<Flight> flightList = flightBookingService.flightBookingService(source, destination, requiredDate);
		return new ResponseEntity<List<Flight>>(flightList, HttpStatus.FOUND);
	}

}
