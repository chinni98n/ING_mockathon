package com.demo.flightbooking.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.mock;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import com.demo.flightbooking.entity.Flight;
import com.demo.flightbooking.entity.Passenger;
import com.demo.flightbooking.repository.FlightRepository;
import com.demo.flightbooking.service.FlightService;
import com.demo.flightbooking.service.PassengerService;

@RunWith(MockitoJUnitRunner.class)
public class FlightBookingServiceTest {
	
	
	  @Mock 
	  FlightRepository flightRepository;
	  
	  @InjectMocks FlightService flightService;
	 
	
	  @Before
		public void setup() {
			MockitoAnnotations.initMocks(this);
		}


	
	/*
	 * @Test(expected=NullPointerException.class) public void createFlight() throws
	 * FlightException {
	 * 
	 * Flight flight = new Flight(); flight.setDate(new Date());
	 * flight.setTime("20:30"); flight.setSource("source");
	 * flight.setDestination("destination"); flight.setSeatAvailable(10);
	 * List<PassengerFlight> list=new ArrayList<PassengerFlight>();
	 * flight.setPassengerFligt(list);
	 * Mockito.when(flightRepository.findByFlightId(Mockito.anyString())).thenReturn
	 * (Optional.of(flight)); flightService.createFlight(flight); }
	 */
	
	
	
	
	
	  @Test(expected = Exception.class)
	  public void testGetFlightById() throws Exception { 
	
	 		  
		 Flight flight=new Flight();
		  Mockito.when(flightService.getFlightById("A123")).thenReturn(flight);
		assertNotNull(flight);
	  }
	  
	 
	  
	  @Test
	  public void testDeleteByFlightId()
	  {
		  PassengerService PassengerService=mock(PassengerService.class);
		  Passenger passenger=new Passenger();
		  passenger.setEmail("pal@gmailkol.com");
		  passenger.setLoggedIn(true);
		  passenger.setPassword("lol");
		  String msg="";
		  Mockito.when(PassengerService.createPassenger(passenger)).thenReturn(msg=msg+"passenger saved successfully");
		  
		  assertEquals("passenger saved successfully", msg);
	
		  
	  }
	  
	 
	

}
